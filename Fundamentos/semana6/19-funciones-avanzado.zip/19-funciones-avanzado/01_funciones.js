'use strict'
/************************************/
/* FUNCTION ==> Funciones Avanzado */
/***********************************/
/* Funcion de primera clase */
/* Un lenguaje de programación se dice que tiene Funciones de primera clase cuando las funciones en ese lenguaje son tratadas como cualquier otra variable. Por ejemplo, en ese lenguaje, una función puede ser pasada como argumento a otras funciones, puede ser retornada por otra función y puede ser asignada a una variable. */

nombre()

/* Fenciónes Declaradas */
function nombre () {
  console.log('declarada')
}

/*  Función de Expreción */
const variable = function () {
  console.log('expresada')
}

variable()

let condicional = true
let fn

if (condicional) {
  fn = function () {console.log('true')}
  // function fn(){console.log('true')}
} else {
  fn = function () {console.log('false')}
  // function fn(){console.log('false')}
}

fn()

/************************************/
/* FUNCTION ==> Funciones Callback */
/***********************************/
/* Una función que pasamos como argumento a otra función se llama callback */

function preguntar(respuesta, si, no) {
  if (respuesta) {
    si()
  } else {
    no()
  }
}

let respuesta = false

function acepto () {
  console.log('Acepto')
}

function rechazo () {
  console.log('Rechazo')
}

const ask = preguntar

ask(respuesta, acepto, rechazo)

/*********************************************/
/* FUNCTION ==> Funciones de Orden Superior */
/*******************************************/
/* Funciones que llaman a otras funciones o que devuelven funciones (closures), se conocen como funciones de orden superior. */

function saludar () {
  return function () {
    return 'hola'
  }
}

console.log(saludar()())

const valor = saludar()
console.log(valor())

/* Closures */
/* Una clausura o closure es una función que permite acceder al ámbito de una función exterior desde una función interior. En JavaScript, las clausuras se crean cada vez que una función es creada. */

function crearContador () {
  let contador = 0
  function incrementar () {
    return contador++
  }

  return incrementar
}

const contador1 = crearContador()
console.log(contador1())
console.log(contador1())
console.log(contador1())
console.log(contador1())
console.log(contador1())
console.log(contador1())

const contador2 = crearContador()
console.log(contador2())
console.log(contador2())
console.log(contador2())

/**************************************/
/* FUNCTION ==> Funciones de Fábrica */
/*************************************/
/* Una función de fábrica es cualquier función que no es una clase o constructor que devuelve un objeto (presumiblemente nuevo). En JavaScript, cualquier función puede devolver un objeto. Cuando lo hace sin la palabra clave "new", es una función de fábrica. */

/* create read update delete */
function crud () {
  const usuarios = []

  return {
    crear (usuario) {
      usuarios.push(usuario)
    },
    leer (callback) {
      callback(usuarios)
    },
    actualizar (usuario) {
      for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].nombre === usuario.nombre) {
          usuarios[i] = usuario
        }
      }
    },
    borrar (usuario) {
      for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].nombre === usuario.nombre) {
          usuarios.splice(i, 1)
        }
      }
    }
  }
}

const grupoA = crud()

grupoA.crear({nombre: 'Jesús'})

grupoA.leer(function (usuarios) {
  console.log(usuarios)
})

grupoA.crear({nombre: 'Juan'})

grupoA.leer(function (usuarios) {
  console.log(usuarios)
})

grupoA.actualizar({nombre: 'Jesús', edad: 30})

grupoA.leer(function (usuarios) {
  console.log(usuarios)
})

grupoA.borrar({nombre: 'Juan'})

grupoA.leer(function (usuarios) {
  console.log(usuarios)
})

const grupoB = crud()

grupoB.leer(function (usuarios) {
  console.log(usuarios)
})

/**************************************/
/* FUNCTION ==> Funciones Recursivas */
/*************************************/
/* La recursión es un patrón de programación que es útil en situaciones en las que una tarea puede dividirse naturalmente en varias tareas del mismo tipo, pero más simples, en el proceso puede llamar a muchas otras funciones. Un caso particular de esto se da cuando una función se llama a sí misma. Esto es lo que se llama recursividad. */

const usuarios = [
  {
    nombre: 'Jesús',
    edad: 20
  },
  {
    nombre: 'Pedro',
    edad: 30
  }, {
    nombre: 'Maria',
    edad: 40
  }
]

/* Dos pensamientos */
/* pensamiento iterativo - for */
for (let i = 0; i < usuarios.length; i++) {
  console.log(usuarios[i])
}

/* pensamiento recursivo */
function recursivo (usuarios, i = 0) {
  if (i < usuarios.length) {
    console.log(usuarios[i])
    recursivo(usuarios, i + 1)
  }
}

recursivo(usuarios)

/*************************************/
/* FUNCTION ==> Funciones de Flecha */
/************************************/
/* Hay otra sintaxis muy simple y concisa para crear funciones, que a menudo es mejor que las Expresiones de funciones. Se llama “funciones de flecha”, porque se ve así: */

/* return inplicito */
const mostrarNombre = n => n 

const resultado = mostrarNombre('José')
console.log(resultado)

const presentar = (nombre, edad) => { 
  let texto = `Hola soy ${nombre}`
   texto += `, y tiene la edad de ${edad}`
  return texto
}

console.log(presentar('Brayan', 20))

let suma = (a,b) => a + b

console.log(suma(1, 2))