/***********************/
/* COERCIÓN DE TIPOS */
/*********************/
// En JavaScript, la coerción es una característica que fuerza a una variable de cierto tipo a tener el comportamiento de una diferente.

/************************************/
/* COERCIÓN DE TIPOS ==> Inplícita */
/***********************************/

/************************************/
/* COERCIÓN DE TIPOS ==> Explícita */
/***********************************/

// Más Info: https://www.notion.so/academlo/Coerci-n-de-Tipos-a85c5d617ee54a34b85ed12d13131734
