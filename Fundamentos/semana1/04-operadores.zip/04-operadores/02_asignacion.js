/******************************/
/* OPERADORES ==> ASIGNACIÓN */
/*****************************/
// Una asignación = también es un operador.

// Más Info: https://www.notion.so/academlo/Operadores-1e1430a1bb7e4c0e90650528e8a0d8b8
