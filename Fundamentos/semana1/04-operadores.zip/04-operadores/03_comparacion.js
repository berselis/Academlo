/********************************/
/* OPERADORES ==> COMPARACIÓN */
/******************************/
// Conocemos muchos operadores de comparación de las matemáticas

/* En JavaScript se escriben así:
  - mayor que >
  - menor que <
  - mayor o igual que >=
  - menor o igual que <=
  - igual a ==
  - diferente de != */

// Más Info: https://www.notion.so/academlo/Operadores-1e1430a1bb7e4c0e90650528e8a0d8b8
