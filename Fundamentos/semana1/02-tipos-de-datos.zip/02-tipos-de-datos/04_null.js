/*********************************/
/* TIPOS DE DATOS ==> #4 NULL   */
/********************************/
// El valor especial null no pertenece a ninguno de los tipos descritos anteriormente. Forma un tipo propio separado que contiene sólo el valor null.

// Más Info: https://www.notion.so/academlo/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
