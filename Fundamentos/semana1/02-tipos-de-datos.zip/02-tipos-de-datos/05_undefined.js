/************************************/
/* TIPOS DE DATOS ==> #5 UNDEFINED */
/***********************************/
// El valor especial undefined también se distingue. Hace un tipo propio, igual que null.

// Más Info: https://www.notion.so/academlo/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
