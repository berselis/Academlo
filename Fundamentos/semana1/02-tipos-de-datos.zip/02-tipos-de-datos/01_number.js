/*********************************/
/* TIPOS DE DATOS ==> #1 NUMBER */
/********************************/
// El tipo number representa tanto números enteros como de punto flotante.

// Más Info: https://www.notion.so/academlo/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
