/**********************************/
/* TIPOS DE DATOS ==> #3 BOOLEAN */
/*********************************/
// Los booleanos son valores lógicos que pueden ser true o false.

// Más Info: https://www.notion.so/academlo/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
