/*********************************/
/* TIPOS DE DATOS ==> #2 STRING */
/********************************/
// El tipo string representa cadenas de caracteres y debe ser entre comillas.

/*
Podemos usar comillas:
  - simples: 'Hola',
  - dobles: "como estas",
también podemos usar comillas invertidas: `bienvenido`
*/

// Más Info: https://www.notion.so/academlo/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
