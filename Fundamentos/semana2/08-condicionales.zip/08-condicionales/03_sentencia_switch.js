/***************************************/
/* CONDICIONALES ==> SENTENCIA SWITCH */
/**************************************/
// La sentencia switch es una forma de evaluar una condición y ejecutar una secuencia de instrucciones dependiendo de la condición.

// Sintaxis
/*
switch (valor) {
  case valor1:
    bloque de código
    break
  case valor2:
    bloque de código
    break
  default:
    bloque de código
  }
*/

// Más información:
