/******************************************/
/* CONDICIONALES ==> OPERADOR TERNARIO ? */
/*****************************************/
// A veces necesitamos asignar una variable dependiendo de alguna condición.

// Más información:
