/***********************************/
/* CONDICIONALES ==> SENTENCIA IF */
/**********************************/
// Algunas veces, necesitamos ejecutar diferentes acciones basadas en diferentes condiciones. La sentencia if evalúa la condición en los paréntesis, y si el resultado es true ejecuta un bloque de código.

// Más información:
