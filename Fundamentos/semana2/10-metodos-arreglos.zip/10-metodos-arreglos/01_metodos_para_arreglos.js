/**********************************/
/* MÉTODOS ==> ARREGLOS (ARRAYS) */
/*********************************/
const frutas = ['Manzana', 'Pera', 'Naranja', 'Sandía', 'Melón', 'Pera']
