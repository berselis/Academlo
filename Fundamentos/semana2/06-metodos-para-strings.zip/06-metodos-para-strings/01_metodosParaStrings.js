/*******************************************/
/* MÉTODOS ==> CADENAS DE TEXTO (STRINGS) */
/******************************************/

const cadenaDeTexto = 'Hola soy una cadena de texto'

// Más Info: https://academlo.notion.site/Tipos-de-Datos-primitivos-ed3f754ef79f4ec1bad36290ce46442e
