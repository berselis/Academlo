/**************************************/
/* TIPOS DE DATOS ==> OBJETOS OBJECT */
/*************************************/
// Los objetos son usados para almacenar colecciones de varios datos y entidades más complejas asociados con un nombre clave.
// { clave: 'valor' } Este par de conceptos vamos a llamarlos como “clave: valor”.

// Más información: https://www.notion.so/academlo/Objetos-a64c564dd8bd4ed38a5a186bb7c39fa4
