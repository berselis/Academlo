/**************************************/
/* TIPOS DE DATOS ==> ARREGLOS ARRAY */
/*************************************/
// Array (llamada en español arreglo o matriz/vector) para almacenar colecciones de datos ordenadas, donde cada elemento tiene un índice.

// Más información: https://www.notion.so/academlo/Arreglos-2a2ef0f854564c9baf7f7a7a4b888c20
