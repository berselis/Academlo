/*******************/
/* BUCLES ==> FOR */
/******************/
// El bucle for es más complejo, pero también el más usado.

/*
Sintaxis:
for (inicialización; condición; operación) {
  // cuerpo del bucle
}
*/
